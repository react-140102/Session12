﻿using BitPayDll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BitPayTest.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public void Send(string Amount, string FactorId, string Name = "", string Email = "", string Description = "")
        {
            BitPay bitpay = new BitPay();

            string Url = "http://bitpay.ir/payment/gateway-send";

            string Redirect = "Return Address";

            string Api = "Your Api";

            int result = bitpay.Send(Url, Api, Amount, Redirect, FactorId, Name, Email, Description);

            if (result > 0 )
            {
                string go = string.Format("http://bitpay.ir/payment/gateway-{0}",result);
                Response.Redirect(go);
            }

        }

        [HttpGet]
        public ActionResult Get()
        {
            BitPay bitpay = new BitPay();

            string url = "http://bitpay.ir/payment/gateway-result-second";

            string api = "Your Api";

            string trans_id = HttpContext.Request["trans_id"];

            string id_get = HttpContext.Request["id_get"];

            string factorId = HttpContext.Request["factorId"];

            int result = bitpay.Get(url,api,trans_id,id_get);

            if (result == 1)
            {
                //true
                TempData["msg"] = string.Format("پرداخت شما با شماره فاکتور {0} موفقیت انجام شد", factorId);
            }
            else
            {
                //false
                TempData["msg"] = "خطا در پرداخت";
            }
            return View();

        }
    }
}